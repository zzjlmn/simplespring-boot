package com.example.demo.dao;

import com.example.demo.mapper.EmployeeMapper;
import com.example.demo.pojo.Department;
import com.example.demo.pojo.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class EmployeeDao {
    @Autowired
    EmployeeMapper employeeMapper;

    public void add(Employee employee){
        employeeMapper.addEmployee(employee);
    }


    public List<Employee> getEmployees(){
        return employeeMapper.selectAll();
    }
    public Employee getEmployeeById(Integer id){
        return new Employee();
    }

    public void Update(int id,Employee newEmployee){

    }

    public void Delete(Integer id){

    }


}
