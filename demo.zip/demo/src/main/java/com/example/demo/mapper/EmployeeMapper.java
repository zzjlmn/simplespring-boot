package com.example.demo.mapper;

import com.example.demo.pojo.Employee;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.web.bind.annotation.Mapping;

import java.util.List;
@Mapper
public interface EmployeeMapper {

    public List<Employee> selectAll();

    public boolean addEmployee(Employee employee);


}
