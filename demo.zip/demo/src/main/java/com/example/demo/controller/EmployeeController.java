package com.example.demo.controller;

import com.example.demo.dao.DepartmentDao;
import com.example.demo.dao.EmployeeDao;
import com.example.demo.pojo.Department;
import com.example.demo.pojo.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Controller
public class EmployeeController {

    static List<String> list=new ArrayList<>();

    @Autowired
    EmployeeDao employeeDao;

    @Autowired
    DepartmentDao departmentDao;

    @RequestMapping("/employee")
    public String list(Model model){
        list.add("教学部");
        list.add("市场部");
        list.add("教研部");
        list.add("运营部");
        list.add("后勤部");
        List<Employee> employees=employeeDao.getEmployees();
        model.addAttribute("employees",employees);
        model.addAttribute("names",list);
        return "list";
    }

    @RequestMapping("/emp/add")
    public String goAdd(Model model){
        Collection<Department> departments = departmentDao.getDepartments();
        model.addAttribute("departments",departments);
        return "emp/add";
    }

    @RequestMapping("/employee/add")
    public String add(Employee employee){
        employeeDao.add(employee);
        return "redirect:/employee";
    }

    @RequestMapping("/emp/update/{id}")
    public String goUpdate(@PathVariable int id,Model model){
        Employee employee = employeeDao.getEmployeeById(id);
        model.addAttribute("employee",employee);
        Collection<Department> departments = departmentDao.getDepartments();
        model.addAttribute("departments",departments);
        return "emp/update";
    }

    @RequestMapping("/employee/update")
    public String update(Employee employee){
        employeeDao.Update(employee.getId(),employee);
        return "redirect:/employee";
    }

    @RequestMapping("/emp/delete/{id}")
    public String delete(Model model, @PathVariable int id){
        employeeDao.Delete(id);
        return "redirect:/employee";
    }
}
