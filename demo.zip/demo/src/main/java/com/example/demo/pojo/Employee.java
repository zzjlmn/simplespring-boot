package com.example.demo.pojo;


import com.example.demo.dao.DepartmentDao;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;



@Data
@AllArgsConstructor
@NoArgsConstructor
public class Employee {

    private Integer id;
    private String name;
    private String email;
    private Integer gender;
    private int departmentId;
    private String birth;

    public Employee(Integer id,String name,String email,Integer gender,int department){
        DepartmentDao departmentDao = new DepartmentDao();
        this.id=id;
        this.name=name;
        this.email=email;
        this.gender=gender;
        this.departmentId=department;
        DateFormat df=new SimpleDateFormat("yyyy-MM-dd");
        birth=df.format(new Date());

    }


}
