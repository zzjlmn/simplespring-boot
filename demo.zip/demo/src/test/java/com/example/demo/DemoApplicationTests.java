package com.example.demo;


import com.example.demo.mapper.EmployeeMapper;
import com.example.demo.pojo.Employee;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

@SpringBootTest
@RunWith(SpringRunner.class)
public class DemoApplicationTests {

    @Autowired
    DataSource dataSource;


    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    EmployeeMapper employeeMapper;

    @Test
    public void contextLoads() throws SQLException {
     List<Employee> list=employeeMapper.selectAll();
        System.out.println(list);



    }

}
